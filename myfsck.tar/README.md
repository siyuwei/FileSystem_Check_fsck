# FileSystem_Check_fsck

This is an implementation of the File System Check program of an ext2 file system.
